This is the unmodified android source code from TI. 
The original source code can be found at: https://git.ti.com/sensortag-20-android

Please note, there are a few branches on this github repo.

master is the one linked above (and was fetched in December 2015, and may be behind that branch).

old-app is the branch from their old version of the app, for sensortag 2541

dev was based off of old-app, which had some bug fixes I made.

I would recommend you use master, which has all the recent updates. Use it with android studio (requires android sdk 21, and build tools 21.1.2)

The code belongs to TI and their license still applies. 
Check their website for the license etc.

